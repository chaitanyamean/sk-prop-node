console.log('Hello World!')

// import {FormsModule} from '@angular/forms'

const fs = require('fs') // Internal Module
const os = require('os')

const appConfig = require('./config/appConfig')
// const location = require('./models/location')
// const user = require('./models/user')

// const passwordLib = require('./libs/passwordlibs')

// External Module
const mongoose = require('mongoose')
const express = require('express') 
const bodyparser = require('body-parser')

const app = express();


// body parser for post methods
 app.use(bodyparser.json())
 app.use(bodyparser.urlencoded({extended: false}))

let modelsPath = './models'

fs.readdirSync(modelsPath).forEach(function (file) {
console.log(modelsPath + '/' + file)
    if(~file.indexOf('.js')) require(modelsPath + '/' + file)
})


const UserModel = mongoose.model('User')

app.post('/signup', (req, res)=> {

    console.log(req.body)
    // res.send(req.body)
    // console.log(req)

    let userDetails = new UserModel({
        userName: req.body.userName,
        password: req.body.password
    })

    userDetails.save((err,result) => {
        if(err) {
            res.send(err)
        } else {
            res.send(result)
        }
    })


})




// let modelsPath = './models'

// //Bootstrap models
// fs.readdirSync(modelsPath).forEach(function (file) {
//     if (~file.indexOf('.js')) require(modelsPath + '/' + file)
// });
// end Bootstrap models
// let modelsPath = './models'
// fs.readdirSync(modelsPath).forEach(function (file) {
//     if(~file.indexOf('.js')) require(modelsPath+ '/'+ file)
// });

// const UserModel = mongoose.model('User')
// /username/:id/:name


// Params ---- req.params
// Query ----- req.query
// body ---- req.body

// body-parser

// app.get('/username/:id/:name', (req,res) => {

//     console.log(req.params)
// res.send(req.params)


// })


// app.get('/userdetails', (req, res) => {
//     console.log(req.query)
//     res.send(req.query)
// })


// app.post('/logindetails' , (req, res) => {
//     console.log(req.body)
//     res.send(req.body)
// })

// app.post('/signup', (req,res) => {
//     console.log(req.body)

   
// })













app.listen(appConfig.port, () => {
 
    let db = mongoose.connect(appConfig.db.url, ({ useNewUrlParser: true }))
    console.log('Port is running in ' + appConfig.port)
})


mongoose.connection.on('error', function(err) {
    if(err) {
        console.log(err)
    }
})

mongoose.connection.on('open', function(err) {
    if(err) {
        console.log(err)

    } else {
        console.log('connection successful')
    }
})



// app.get('/', (req, res) => res.send('Hello'))

// fs.readdirSync(routesPath).forEach(function (file) {
    //         console.log('Including the file')
    //     if(~file.indexOf('.js')){
//         console.log(routesPath + '/'+ file)
//         let route = require(routesPath + '/'+ file)
//         route.setRouter(app);
//     }
// })











/*
PORT
CORS *
Envoriment: dev // http://localhost:3000
            prod // http://www.srkpropertis.com
DB: https://127.0.0.1:27017/nodeDB


srproperties.com/admin
srproperties.com/customer

*/




















//const http = require('http')

// http.createServer((req, res) => {
//  res.end('Hello World')
// }).listen(3000)

// let userDetails = os.userInfo()
// console.log(userDetails)
// fs.appendFileSync('greetings.txt', 'Hello ' + userDetails.username)

